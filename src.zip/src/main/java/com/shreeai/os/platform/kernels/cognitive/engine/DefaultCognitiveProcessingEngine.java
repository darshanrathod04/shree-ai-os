package com.shreeai.os.platform.kernels.cognitive.engine;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

import com.shreeai.os.platform.kernels.cognitive.model.CognitiveState;
import com.shreeai.os.platform.kernels.cognitive.model.DecisionContext;
import com.shreeai.os.platform.kernels.cognitive.model.EvaluationCriteria;
import com.shreeai.os.platform.kernels.cognitive.model.Hypothesis;
import com.shreeai.os.platform.kernels.cognitive.model.ReasoningRequest;
import com.shreeai.os.platform.kernels.cognitive.model.ReflectionScope;

/**
 * <b>DefaultCognitiveProcessingEngine</b>
 *
 * <p>Default implementation of the cognitive processing engine.</p>
 *
 * <p><b>Architectural Responsibility:</b></p>
 * <ul>
 *   <li>Executes deterministic cognitive processing</li>
 *   <li>Transforms validated domain models</li>
 *   <li>Produces immutable processing results</li>
 * </ul>
 *
 * <p><b>Ownership:</b> Cognitive Kernel - Engine Layer</p>
 * <p><b>Version:</b> 1.0</p>
 *
 * <p><b>Invariant:</b> This class is stateless, deterministic, thread-safe, and read-only.
 * It maintains no mutable fields and performs deterministic computation only.</p>
 *
 * <p><b>Constitutional Authority:</b> EIO-COG-106, EIO-ARCH-001</p>
 *
 * <p><b>Processing Responsibilities:</b></p>
 * <p>The engine performs deterministic computation only. It transforms validated
 * cognitive inputs into immutable processing results without introducing adaptive
 * behavior, learning, orchestration, or autonomous decision-making.</p>
 *
 * <p><b>What This Engine Does NOT Do:</b></p>
 * <ul>
 *   <li>Does not validate requests (validation is handled by the service layer)</li>
 *   <li>Does not translate exceptions (exception translation is handled by the service layer)</li>
 *   <li>Does not perform adaptive learning or probabilistic reasoning</li>
 *   <li>Does not execute workflow orchestration</li>
 *   <li>Does not access persistence or networking</li>
 *   <li>Does not integrate with AI providers</li>
 * </ul>
 *
 * @since 1.0
 */
public final class DefaultCognitiveProcessingEngine implements CognitiveProcessingEngine<CognitiveProcessingResult> {

    /**
     * Private constructor to prevent instantiation.
     *
     * <p>This class provides only static factory methods and should not be instantiated.</p>
     */
    private DefaultCognitiveProcessingEngine() {
        // Prevent instantiation
    }

    /**
     * Processes a reasoning request.
     *
     * <p>Executes deterministic reasoning computation on the validated request.
     * Transforms the request into an immutable processing result.</p>
     *
     * @param request the reasoning request to process (must not be {@code null})
     * @param context the cognitive state context (must not be {@code null})
     * @return the processing result
     */
    @Override
    public CognitiveProcessingResult processReasoning(ReasoningRequest request, CognitiveState context) {
        // Deterministic processing - transform inputs to result
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("operation", "reasoning");
        metadata.put("requestId", request.id().value());
        metadata.put("stateName", context.stateName());
        metadata.put("processedAt", Instant.now());

        // Create deterministic result
        Object result = Map.of(
                "status", "processed",
                "objective", request.reasoningObjective(),
                "inputs", request.inputs()
        );

        return new CognitiveProcessingResult(
                true,
                Instant.now(),
                metadata,
                result,
                context
        );
    }

    /**
     * Processes an inference request.
     *
     * <p>Executes deterministic inference computation on the validated inputs.
     * Transforms the inputs into an immutable processing result.</p>
     *
     * @param request the reasoning request (must not be {@code null})
     * @param state the cognitive state (must not be {@code null})
     * @return the processing result
     */
    @Override
    public CognitiveProcessingResult processInference(ReasoningRequest request, CognitiveState state) {
        // Deterministic processing - transform inputs to result
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("operation", "inference");
        metadata.put("requestId", request.id().value());
        metadata.put("stateName", state.stateName());
        metadata.put("processedAt", Instant.now());

        // Create deterministic result
        Object result = Map.of(
                "status", "inferred",
                "objective", request.reasoningObjective(),
                "constraints", request.constraints()
        );

        return new CognitiveProcessingResult(
                true,
                Instant.now(),
                metadata,
                result,
                state
        );
    }

    /**
     * Processes a decision request.
     *
     * <p>Executes deterministic decision computation on the validated inputs.
     * Transforms the inputs into an immutable processing result.</p>
     *
     * @param context the decision context (must not be {@code null})
     * @param criteria the evaluation criteria (must not be {@code null})
     * @param state the cognitive state (must not be {@code null})
     * @return the processing result
     */
    @Override
    public CognitiveProcessingResult processDecision(
            DecisionContext context,
            EvaluationCriteria criteria,
            CognitiveState state) {

        DecisionIntelligenceAnalysis analysis =
                analyzeDecision(
                        context,
                        criteria
                );

        Map<String, Object> metadata = new HashMap<>();

        metadata.put("operation", "decision");
        metadata.put("decisionIntelligenceVersion", "1.0");
        metadata.put("contextId", context.id().value());
        metadata.put("criteriaId", criteria.id().value());
        metadata.put(
                "alternativesCount",
                context.availableAlternatives().size()
        );
        metadata.put(
                "evaluatedAlternatives",
                analysis.evaluatedAlternativeCount()
        );
        metadata.put(
                "decisionStatus",
                analysis.status()
        );
        metadata.put(
                "decisionConfidence",
                analysis.confidence()
        );
        metadata.put(
                "recommendationSupported",
                analysis.recommendationSupported()
        );
        metadata.put(
                "riskCount",
                analysis.risks().size()
        );
        metadata.put(
                "tradeOffCount",
                analysis.tradeOffs().size()
        );
        metadata.put(
                "missingInformationCount",
                analysis.missingInformation().size()
        );
        metadata.put("processedAt", Instant.now());

        /*
         * Map.of(...) supports at most 10 key/value pairs.
         * Decision analysis exposes more fields, so build the result
         * incrementally and freeze it before returning.
         */
        Map<String, Object> resultMap = new java.util.LinkedHashMap<>();

        resultMap.put(
                "status",
                analysis.status()
        );

        resultMap.put(
                "alternatives",
                analysis.alternatives()
        );

        resultMap.put(
                "criteria",
                criteria.criterionName()
        );

        resultMap.put(
                "criterionWeight",
                criteria.weight()
        );

        resultMap.put(
                "priority",
                criteria.priority()
        );

        resultMap.put(
                "recommendation",
                analysis.recommendation()
        );

        resultMap.put(
                "recommendationSupported",
                analysis.recommendationSupported()
        );

        resultMap.put(
                "confidence",
                analysis.confidence()
        );

        resultMap.put(
                "rationale",
                analysis.rationale()
        );

        resultMap.put(
                "risks",
                analysis.risks()
        );

        resultMap.put(
                "tradeOffs",
                analysis.tradeOffs()
        );

        resultMap.put(
                "missingInformation",
                analysis.missingInformation()
        );

        resultMap.put(
                "intelligence",
                analysis.intelligenceMetadata()
        );

        Object result = Map.copyOf(resultMap);

        return new CognitiveProcessingResult(
                true,
                Instant.now(),
                metadata,
                result,
                state
        );
    }


    /**
     * Advanced deterministic decision analysis.
     *
     * <p>
     * This implementation deliberately does not invent scores for alternatives.
     * The current DecisionContext contract exposes alternatives, while the
     * current EvaluationCriteria contract exposes criterion configuration.
     * Therefore this layer evaluates decision readiness, structural quality,
     * ambiguity, coverage, and recommendation safety. A future evidence/scoring
     * contract can plug into this analysis without changing the public processing
     * result shape.
     * </p>
     */
    private DecisionIntelligenceAnalysis analyzeDecision(
            DecisionContext context,
            EvaluationCriteria criteria) {

        java.util.List<String> alternatives =
                normalizeAlternatives(
                        context.availableAlternatives()
                );

        java.util.List<String> risks =
                new java.util.ArrayList<>();

        java.util.List<String> tradeOffs =
                new java.util.ArrayList<>();

        java.util.List<String> missingInformation =
                new java.util.ArrayList<>();

        boolean criteriaNameValid =
                criteria.criterionName() != null
                        && !criteria.criterionName().isBlank();

        boolean weightValid =
                criteria.weight() > 0.0;

        boolean priorityValid =
                criteria.priority() != null
                        && !criteria.priority().isBlank();

        if (alternatives.isEmpty()) {
            missingInformation.add(
                    "At least one decision alternative"
            );
            risks.add(
                    "No decision alternatives are available for evaluation"
            );
        }

        if (alternatives.size() == 1) {
            risks.add(
                    "Only one alternative is available; comparative decision intelligence is limited"
            );
        }

        if (hasDuplicateAlternatives(
                context.availableAlternatives()
        )) {
            risks.add(
                    "Duplicate alternatives were detected and removed from the analytical set"
            );
        }

        if (!criteriaNameValid) {
            missingInformation.add(
                    "A meaningful evaluation criterion"
            );
            risks.add(
                    "The evaluation criterion is missing or blank"
            );
        }

        if (!weightValid) {
            missingInformation.add(
                    "A positive evaluation criterion weight"
            );
            risks.add(
                    "The evaluation criterion has no positive weight"
            );
        }

        if (!priorityValid) {
            risks.add(
                    "Criterion priority is not explicitly defined"
            );
        }

        if (alternatives.size() >= 2) {
            tradeOffs.add(
                    "A comparative trade-off requires alternative-specific evidence; "
                            + "the current context does not expose such evidence"
            );

            missingInformation.add(
                    "Alternative-specific evaluation evidence"
            );
        }

        /*
         * Critical safety invariant:
         *
         * Do not manufacture a winner from alternative names, list order,
         * criterion name, or criterion weight. Those values do not establish
         * comparative merit.
         */
        String status;

        boolean recommendationSupported = false;

        String recommendation =
                "No reliable recommendation can be produced from the current decision context.";

        if (alternatives.isEmpty()) {

            status = "NO_ALTERNATIVES";

        } else if (!criteriaNameValid) {

            status = "INSUFFICIENT_CRITERIA";

        } else {

            status = "INSUFFICIENT_DISCRIMINATING_EVIDENCE";
        }

        double confidence =
                calculateDecisionReadinessConfidence(
                        alternatives,
                        criteriaNameValid,
                        weightValid,
                        priorityValid
                );

        String rationale =
                buildDecisionRationale(
                        status,
                        alternatives,
                        criteria,
                        confidence
                );

        java.util.Map<String, Object> intelligence =
                new java.util.LinkedHashMap<>();

        intelligence.put(
                "engine",
                "Deterministic Decision Intelligence"
        );

        intelligence.put(
                "version",
                "1.0"
        );

        intelligence.put(
                "scoringPolicy",
                "NO_SCORE_FABRICATION"
        );

        intelligence.put(
                "evaluationMode",
                "DECISION_READINESS_AND_EVIDENCE_GATED"
        );

        intelligence.put(
                "alternativeCount",
                alternatives.size()
        );

        intelligence.put(
                "criteriaConfigured",
                criteriaNameValid
        );

        intelligence.put(
                "criterionWeightConfigured",
                weightValid
        );

        intelligence.put(
                "priorityConfigured",
                priorityValid
        );

        intelligence.put(
                "recommendationSupported",
                recommendationSupported
        );

        intelligence.put(
                "confidence",
                confidence
        );

        intelligence.put(
                "requiresAdditionalEvidence",
                true
        );

        return new DecisionIntelligenceAnalysis(
                status,
                alternatives,
                alternatives.size() == 0
                        ? 0
                        : 0,
                recommendation,
                recommendationSupported,
                confidence,
                rationale,
                java.util.List.copyOf(
                        deduplicateStrings(risks)
                ),
                java.util.List.copyOf(
                        deduplicateStrings(tradeOffs)
                ),
                java.util.List.copyOf(
                        deduplicateStrings(missingInformation)
                ),
                java.util.Map.copyOf(
                        intelligence
                )
        );
    }

    private double calculateDecisionReadinessConfidence(
            java.util.List<String> alternatives,
            boolean criteriaConfigured,
            boolean weightConfigured,
            boolean priorityConfigured) {

        if (alternatives.isEmpty()) {
            return 0.05;
        }

        double readiness = 0.0;

        if (criteriaConfigured) {
            readiness += 0.30;
        }

        if (weightConfigured) {
            readiness += 0.20;
        }

        if (priorityConfigured) {
            readiness += 0.10;
        }

        if (alternatives.size() >= 2) {
            readiness += 0.15;
        }

        /*
         * Deliberately capped because there is no alternative-specific
         * evidence/scoring contract in the current models.
         */
        readiness += 0.05;

        return clamp(
                readiness,
                0.05,
                0.50
        );
    }

    private String buildDecisionRationale(
            String status,
            java.util.List<String> alternatives,
            EvaluationCriteria criteria,
            double confidence) {

        if ("NO_ALTERNATIVES".equals(status)) {

            return "Decision analysis cannot begin because no alternatives "
                    + "are available.";
        }

        if ("INSUFFICIENT_CRITERIA".equals(status)) {

            return "Decision analysis cannot establish a meaningful comparison "
                    + "because the evaluation criterion is not configured.";
        }

        return "Decision intelligence identified "
                + alternatives.size()
                + " alternative(s) and evaluated the configured criterion '"
                + criteria.criterionName()
                + "'. However, the current decision context does not expose "
                + "alternative-specific evidence or scores. The engine therefore "
                + "refuses to fabricate a winner. Decision-readiness confidence="
                + String.format(
                java.util.Locale.ROOT,
                "%.2f",
                confidence
        )
                + ".";
    }

    private java.util.List<String> normalizeAlternatives(
            java.util.List<String> alternatives) {

        if (alternatives == null) {
            return java.util.List.of();
        }

        return alternatives.stream()
                .filter(
                        java.util.Objects::nonNull
                )
                .map(
                        String::trim
                )
                .filter(
                        value -> !value.isBlank()
                )
                .distinct()
                .toList();
    }

    private boolean hasDuplicateAlternatives(
            java.util.List<String> alternatives) {

        if (alternatives == null
                || alternatives.size() < 2) {

            return false;
        }

        java.util.Set<String> normalized =
                new java.util.HashSet<>();

        for (String alternative : alternatives) {

            if (alternative == null) {
                continue;
            }

            if (!normalized.add(
                    alternative.trim().toLowerCase(
                            java.util.Locale.ROOT
                    )
            )) {
                return true;
            }
        }

        return false;
    }

    private java.util.List<String> deduplicateStrings(
            java.util.List<String> values) {

        return new java.util.ArrayList<>(
                new java.util.LinkedHashSet<>(
                        values
                )
        );
    }

    private double clamp(
            double value,
            double minimum,
            double maximum) {

        return Math.max(
                minimum,
                Math.min(
                        maximum,
                        value
                )
        );
    }

    /**
     * Immutable result of the decision-intelligence analysis.
     */
    private record DecisionIntelligenceAnalysis(
            String status,
            java.util.List<String> alternatives,
            int evaluatedAlternativeCount,
            String recommendation,
            boolean recommendationSupported,
            double confidence,
            String rationale,
            java.util.List<String> risks,
            java.util.List<String> tradeOffs,
            java.util.List<String> missingInformation,
            java.util.Map<String, Object> intelligenceMetadata) {
    }

    /**
     * Processes a reflection request.
     *
     * <p>Executes deterministic reflection computation on the validated inputs.
     * Transforms the inputs into an immutable processing result.</p>
     *
     * @param scope the reflection scope (must not be {@code null})
     * @param state the cognitive state (must not be {@code null})
     * @return the processing result
     */
    @Override
    public CognitiveProcessingResult processReflection(ReflectionScope scope, CognitiveState state) {
        // Deterministic processing - transform inputs to result
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("operation", "reflection");
        metadata.put("scopeId", scope.id().value());
        metadata.put("target", scope.reflectionTarget());
        metadata.put("artifactsCount", scope.includedArtifacts().size());
        metadata.put("processedAt", Instant.now());

        // Create deterministic result
        Object result = Map.of(
                "status", "reflected",
                "target", scope.reflectionTarget(),
                "boundaries", scope.analysisBoundaries()
        );

        return new CognitiveProcessingResult(
                true,
                Instant.now(),
                metadata,
                result,
                state
        );
    }

    /**
     * Processes a cognitive state operation.
     *
     * <p>Executes deterministic state computation on the validated inputs.
     * Transforms the inputs into an immutable processing result.</p>
     *
     * @param currentState the current cognitive state (must not be {@code null})
     * @param transition the state transition data (must not be {@code null})
     * @return the processing result
     */
    @Override
    public CognitiveProcessingResult processCognitiveState(CognitiveState currentState, Map<String, Object> transition) {
        // Deterministic processing - transform inputs to result
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("operation", "stateTransition");
        metadata.put("stateId", currentState.id().value());
        metadata.put("currentStateName", currentState.stateName());
        metadata.put("transitionKeys", transition.keySet());
        metadata.put("processedAt", Instant.now());

        // Create deterministic result - state remains unchanged in this implementation
        Object result = Map.of(
                "status", "transitionProcessed",
                "currentState", currentState.stateName(),
                "transitionApplied", transition
        );

        return new CognitiveProcessingResult(
                true,
                Instant.now(),
                metadata,
                result,
                currentState
        );
    }

    /**
     * Processes a recommendation request.
     *
     * <p>Executes deterministic recommendation computation on the validated inputs.
     * Transforms the inputs into an immutable processing result.</p>
     *
     * @param context the decision context (must not be {@code null})
     * @param criteria the evaluation criteria (must not be {@code null})
     * @param state the cognitive state (must not be {@code null})
     * @return the processing result
     */
    @Override
    public CognitiveProcessingResult processRecommendation(
            DecisionContext context,
            EvaluationCriteria criteria,
            CognitiveState state) {

        DecisionIntelligenceAnalysis analysis =
                analyzeDecision(
                        context,
                        criteria
                );

        Map<String, Object> metadata = new HashMap<>();

        metadata.put("operation", "recommendation");
        metadata.put("decisionIntelligenceVersion", "1.0");
        metadata.put("contextId", context.id().value());
        metadata.put("criteriaId", criteria.id().value());
        metadata.put(
                "alternativesCount",
                context.availableAlternatives().size()
        );
        metadata.put(
                "evaluatedAlternatives",
                analysis.evaluatedAlternativeCount()
        );
        metadata.put(
                "recommendationStatus",
                analysis.status()
        );
        metadata.put(
                "recommendationConfidence",
                analysis.confidence()
        );
        metadata.put(
                "recommendationSupported",
                analysis.recommendationSupported()
        );
        metadata.put("processedAt", Instant.now());

        Object result = Map.of(
                "status",
                analysis.status(),

                "recommendation",
                analysis.recommendation(),

                "recommendationSupported",
                analysis.recommendationSupported(),

                "confidence",
                analysis.confidence(),

                "rationale",
                analysis.rationale(),

                "alternatives",
                analysis.alternatives(),

                "risks",
                analysis.risks(),

                "tradeOffs",
                analysis.tradeOffs(),

                "missingInformation",
                analysis.missingInformation(),

                "intelligence",
                analysis.intelligenceMetadata()
        );

        return new CognitiveProcessingResult(
                true,
                Instant.now(),
                metadata,
                result,
                state
        );
    }

    /**
     * Processes an analysis request.
     *
     * <p>Executes deterministic analysis computation on the validated inputs.
     * Transforms the inputs into an immutable processing result.</p>
     *
     * @param hypothesis the hypothesis to analyze (must not be {@code null})
     * @param state the cognitive state (must not be {@code null})
     * @return the processing result
     */
    @Override
    public CognitiveProcessingResult processAnalysis(Hypothesis hypothesis, CognitiveState state) {
        // Deterministic processing - transform inputs to result
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("operation", "analysis");
        metadata.put("hypothesisId", hypothesis.id().value());
        metadata.put("statement", hypothesis.statement());
        metadata.put("evidenceCount", hypothesis.supportingEvidenceReferences().size());
        metadata.put("processedAt", Instant.now());

        // Create deterministic result
        Object result = Map.of(
                "status", "analyzed",
                "hypothesis", hypothesis.statement(),
                "assumptions", hypothesis.assumptions(),
                "evidence", hypothesis.supportingEvidenceReferences()
        );

        return new CognitiveProcessingResult(
                true,
                Instant.now(),
                metadata,
                result,
                state
        );
    }

    /**
     * Processes an evaluation request.
     *
     * <p>Executes deterministic evaluation computation on the validated inputs.
     * Transforms the inputs into an immutable processing result.</p>
     *
     * @param criteria the evaluation criteria (must not be {@code null})
     * @param state the cognitive state (must not be {@code null})
     * @return the processing result
     */
    @Override
    public CognitiveProcessingResult processEvaluation(EvaluationCriteria criteria, CognitiveState state) {
        // Deterministic processing - transform inputs to result
        Map<String, Object> metadata = new HashMap<>();
        metadata.put("operation", "evaluation");
        metadata.put("criteriaId", criteria.id().value());
        metadata.put("criterionName", criteria.criterionName());
        metadata.put("weight", criteria.weight());
        metadata.put("priority", criteria.priority());
        metadata.put("processedAt", Instant.now());

        // Create deterministic result
        Object result = Map.of(
                "status", "evaluated",
                "criterion", criteria.criterionName(),
                "weight", criteria.weight(),
                "priority", criteria.priority()
        );

        return new CognitiveProcessingResult(
                true,
                Instant.now(),
                metadata,
                result,
                state
        );
    }
}