package com.shreeai.os.platform.kernels.cognitive.api;

/**
 * <b>DecisionContext</b>
 *
 * <p>Represents the context for decision-making operations.</p>
 *
 * <p><b>Architectural Responsibility:</b></p>
 * <ul>
 *   <li>Value object for decision context.</li>
 *   <li>Contains no behavior — data carrier only.</li>
 * </ul>
 *
 * <p><b>Ownership:</b> Cognitive Kernel</p>
 * <p><b>Version:</b> 1.0</p>
 *
 * <p><b>Constitutional Authority:</b> EIO-COG-101, EIO-ARCH-001</p>
 */
public interface DecisionContext {
}